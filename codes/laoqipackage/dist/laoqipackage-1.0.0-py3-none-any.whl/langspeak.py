#coding:utf-8
'''
filename: langspeak.py
'''
class LangSpeak:
    def speak(self):
        return "Everyone should learn programming language."
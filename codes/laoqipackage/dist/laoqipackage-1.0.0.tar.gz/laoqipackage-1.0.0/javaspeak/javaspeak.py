#coding:utf-8
'''
filename: javaspeak.py
'''
class JavaSpeak:
    def speak(self):
        return "Java! Java!"